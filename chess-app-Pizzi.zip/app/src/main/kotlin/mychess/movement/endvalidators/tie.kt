package mychess.movement.endvalidators

import mychess.board.Board
import mychess.result.ResultValidator

class tie : MatchEndingValidator {
    override fun validate(board: Board): ResultValidator {
        TODO("Not yet implemented")
    }
}