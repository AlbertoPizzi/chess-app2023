package mychess.result

import edu.austral.dissis.chess.gui.MoveResult

class GameOver(val message : String) : ResultValidator {
}