package mychess.result

sealed interface ResultValidator