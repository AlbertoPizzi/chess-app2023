package mychess.result

data class SuccessfulResult(val message : String) : ResultValidator