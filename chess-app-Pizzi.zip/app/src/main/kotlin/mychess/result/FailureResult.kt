package mychess.result

data class FailureResult (val message : String) : ResultValidator