package mychess.board

enum class BoardType {
    REGULAR,
    CHECKERS
}