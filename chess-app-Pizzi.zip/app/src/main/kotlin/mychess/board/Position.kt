package mychess.board

data class Position(val column: Int, val row: Int)
