package mychess.exceptions

class InvalidMovementException( message: String) : Exception(message)