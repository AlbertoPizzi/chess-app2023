package mychess.exceptions

class PieceNotFoundException(message : String) : Exception(message)
