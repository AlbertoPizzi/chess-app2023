package mychess.piece

enum class PieceType {
    PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING
}