package mychess.piece

enum class Color {
    BLACK, WHITE
}